# Exchange-Rate Forecasting for Overseas Tuition Planning

Financial Time Series Analysis group project.

## Problem

Sri Lankan students pay overseas tuition fees in foreign currencies.
Even when the tuition fee remains unchanged, its cost in Sri Lankan
rupees changes with exchange rates.

This project forecasts exchange rates and volatility to help students
and families estimate payment costs and understand budget uncertainty.

## Objectives

- Forecast exchange rates 5 and 20 reporting days ahead.
- Compare traditional time-series and machine-learning models.
- Analyse stationarity, autocorrelation, and volatility.
- Estimate tuition costs in LKR with prediction intervals.

## Data Sources

Daily exchange-rate data from FRED, sourced from the US Federal Reserve.
Proposed study period: 2000-2025

| Series | Measurement | Source |
|---|---|---|
| DEXSLUS | LKR per USD | https://fred.stlouisfed.org/series/DEXSLUS |
| DEXUSUK | USD per GBP | https://fred.stlouisfed.org/series/DEXUSUK |
| DEXUSEU | USD per EUR | https://fred.stlouisfed.org/series/DEXUSEU |

We will align observations by date and calculate:

- LKR per USD = DEXSLUS
- LKR per GBP = DEXSLUS × DEXUSUK
- LKR per EUR = DEXSLUS × DEXUSEU

GBP/LKR and EUR/LKR are derived cross-rates, not bank selling rates.
Coverage and missing values will be checked before modelling.

## Models

### Exchange-rate forecasting
- Naïve/random walk baseline
- ARIMA
- Random Forest
- XGBoost

### Volatility forecasting
- Historical variance or EWMA baseline
- GARCH(1,1)
- Optional EGARCH extension

Traditional models will be fitted separately for each currency.
A pooled machine-learning model may use one-hot encoded currency,
lagged rates, past returns, and rolling statistics.

## Evaluation Plan

Proposed chronological split:

| Period | Purpose |
|---|---|
| 2000-2022| Training |
| 2023 | Validation and parameter tuning |
| 2024–2025 | Final testing |

We will use walk-forward evaluation and prevent future-data leakage.
The 5-day and 20-day horizons will be evaluated separately.

- Exchange-rate forecasts: MAE and RMSE by currency and horizon.
- Volatility forecasts: QLIKE and/or MSE against suitable variance proxies.
- Prediction intervals: coverage and width.

All forecasting models will be compared against appropriate baselines.

## Tuition-Cost Application

Estimated tuition cost in LKR =
foreign-currency tuition amount × forecast exchange rate.

The tuition amount is a specified input and is assumed unchanged
during the forecast period. Historical tuition-fee data is not required.

## Planned Project Structure

- data/raw/ — original downloaded datasets
- data/processed/ — cleaned and combined datasets
- notebooks/ — preparation, EDA, and modelling notebooks
- src/ — reusable Python functions
- results/ — forecasts, evaluation tables, and figures
- report/ — report drafts
- requirements.txt — Python dependencies

## Collaboration

- Create a separate branch for each task.
- Submit changes through pull requests.
- Avoid editing the same notebook simultaneously.
- Use relative file paths.
- Keep original data unchanged.
- Agree on shared data formats and evaluation rules before modelling.

## Group Members

| Member | Responsibility |
|---|---|
| Add name | Data preparation |
| Add name | EDA and traditional models |
| Add name | Machine-learning models |
| Add name | Volatility analysis |
| Add name | Evaluation and report integration |

## Limitations

Forecasts support budgeting and cannot guarantee the cheapest payment
date. Unexpected shocks may cause large errors. The currency series
share the LKR component and are related. Actual payments include bank
spreads and transfer charges.

## Project Status

Planning stage. Data preparation, modelling, and evaluation are pending.
Setup instructions and results will be added as work progresses.
