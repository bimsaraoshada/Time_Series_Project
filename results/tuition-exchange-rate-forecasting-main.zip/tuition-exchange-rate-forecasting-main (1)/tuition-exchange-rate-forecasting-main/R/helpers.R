# helpers.R - helper functions used by 02_exploratory_data_analysis.R
# These reproduce the pandas / statsmodels calculations from the Python
# notebook so the R tables match the Python tables.

# The functions below reproduce what pandas / statsmodels do in the Python
# notebook, so that the R tables match the Python tables.

if (!requireNamespace("tseries", quietly = TRUE)) {
  stop("Please install the 'tseries' package: install.packages('tseries')")
}

# ---- pandas-style describe(), skew() and kurtosis() ----
describe_cols <- function(x) {
  t(sapply(x, function(v) {
    v <- v[!is.na(v)]
    q <- quantile(v, c(0.25, 0.5, 0.75), names = FALSE)
    c(count = length(v), mean = mean(v), std = sd(v), min = min(v),
      `25%` = q[1], `50%` = q[2], `75%` = q[3], max = max(v))
  }))
}

pd_skew <- function(v) {              # bias-adjusted skewness (pandas .skew())
  v <- v[!is.na(v)]; n <- length(v); m <- v - mean(v)
  m2 <- mean(m^2); m3 <- mean(m^3)
  sqrt(n * (n - 1)) / (n - 2) * m3 / m2^1.5
}

pd_kurt <- function(v) {              # bias-adjusted excess kurtosis (pandas .kurtosis())
  v <- v[!is.na(v)]; n <- length(v); m <- v - mean(v)
  m2 <- mean(m^2); m4 <- mean(m^4)
  g2 <- m4 / m2^2 - 3
  (n - 1) / ((n - 2) * (n - 3)) * ((n + 1) * g2 + 6)
}

# ---- rolling standard deviation (window = 20, min_periods = 15) ----
rolling_sd <- function(x, window = 20, min_periods = 15) {
  out <- rep(NA_real_, length(x))
  for (i in seq_along(x)) {
    w <- x[max(1, i - window + 1):i]
    w <- w[!is.na(w)]
    if (length(w) >= min_periods) out[i] <- sd(w)
  }
  out
}

# ---- ACF / PACF plots without lag 0 ----
plot_acf_r <- function(x, lags = 30, main = "") {
  a <- as.numeric(acf(x, lag.max = lags, plot = FALSE)$acf)[-1]
  plot(1:lags, a, type = "h", ylim = c(-1, 1), xlab = "Lag", ylab = "ACF", main = main)
  points(1:lags, a, pch = 16, cex = 0.7)
  abline(h = 0)
  b <- 1.96 / sqrt(length(x)); abline(h = c(-b, b), lty = 2, col = "blue")
}

plot_pacf_r <- function(x, lags = 30, main = "") {
  a <- as.numeric(pacf(x, lag.max = lags, plot = FALSE)$acf)
  plot(1:lags, a, type = "h", ylim = c(-1, 1), xlab = "Lag", ylab = "Partial ACF", main = main)
  points(1:lags, a, pch = 16, cex = 0.7)
  abline(h = 0)
  b <- 1.96 / sqrt(length(x)); abline(h = c(-b, b), lty = 2, col = "blue")
}

# ---- Augmented Dickey-Fuller test (constant, AIC lag selection) ----
# Same algorithm and MacKinnon p-values as statsmodels.adfuller(autolag = "AIC").
mackinnon_p <- function(t) {
  if (t > 2.74) return(1)
  if (t < -18.83) return(0)
  coefs <- if (t <= -1.61) c(2.1659, 1.4412, 0.038269) else
                           c(1.7339, 0.93202, -0.12745, -0.010368)
  pnorm(sum(coefs * t^(seq_along(coefs) - 1)))
}

adf_test <- function(x) {
  x <- as.numeric(x[!is.na(x)]); N <- length(x)
  dx <- diff(x); n_dx <- length(dx)
  maxlag <- min(N %/% 2 - 2, ceiling(12 * (N / 100)^0.25))

  fit_k <- function(k, nobs) {
    idx <- (n_dx - nobs + 1):n_dx
    X <- cbind(x[idx])                               # lagged level
    if (k > 0) for (j in seq_len(k)) X <- cbind(X, dx[idx - j])
    X <- cbind(X, 1)                                 # constant
    y <- dx[idx]
    f <- lm.fit(X, y)
    rss <- sum(f$residuals^2); n <- length(y)
    list(X = X, f = f, rss = rss, n = n,
         aic = n * (log(2 * pi) + log(rss / n) + 1) + 2 * ncol(X))
  }

  aics <- sapply(0:maxlag, function(k) fit_k(k, n_dx - maxlag)$aic)
  k <- which.min(aics) - 1                           # chosen number of lags
  m <- fit_k(k, n_dx - k)                            # refit on the largest sample
  s2 <- m$rss / (m$n - ncol(m$X))
  tstat <- unname(m$f$coefficients[1]) / sqrt(s2 * solve(crossprod(m$X))[1, 1])
  list(stat = tstat, p = mackinnon_p(tstat), lags = k, nobs = m$n)
}

adf_crit5 <- function(nobs) {         # 5% critical value (MacKinnon, constant only)
  -2.86154 - 2.8903 / nobs - 4.234 / nobs^2 - 40.040 / nobs^3
}

# ---- KPSS (level stationarity) p-value; tseries bounds it to [0.01, 0.10] ----
kpss_p <- function(x) {
  suppressWarnings(tseries::kpss.test(as.numeric(x), null = "Level")$p.value)
}

# ---- Jarque-Bera test and ARCH-LM test ----
jb_test <- function(x) {
  x <- x[!is.na(x)]; n <- length(x); m <- x - mean(x); m2 <- mean(m^2)
  S <- mean(m^3) / m2^1.5
  K <- mean(m^4) / m2^2
  jb <- n / 6 * (S^2 + (K - 3)^2 / 4)
  list(stat = jb, p = pchisq(jb, df = 2, lower.tail = FALSE), skew = S, kurt = K)
}

arch_lm <- function(x, nlags = 10) {
  e <- as.numeric(x)^2; n <- length(e)
  y <- e[(nlags + 1):n]
  X <- sapply(1:nlags, function(j) e[(nlags + 1 - j):(n - j)])
  r2 <- summary(lm(y ~ X))$r.squared
  stat <- length(y) * r2
  c(stat = stat, p = pchisq(stat, df = nlags, lower.tail = FALSE))
}
